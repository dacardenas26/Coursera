import UIKit

enum Velocidades : Int{
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    init (velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    
    init (velocidadd : Velocidades){
        self.velocidad = velocidadd
    }
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String){
        switch self.velocidad.rawValue {
        case 0:
            velocidad = Velocidades.VelocidadBaja
        case 20:
            velocidad = Velocidades.VelocidadMedia
        case 50:
            velocidad = Velocidades.VelocidadAlta
        case 120:
            velocidad = Velocidades.VelocidadMedia
        default:
            velocidad = Velocidades.Apagado
        }
        return (self.velocidad.rawValue, ": \(self.velocidad)")
    }
}

var carro : Auto = Auto(velocidadd: Velocidades.Apagado)
for _ in 0...20 {
    print ("\(carro.velocidad.rawValue), \(carro.velocidad)")
    carro.cambioDeVelocidad()
}


/* La clase Auto tiene los siguientes atributos:

- Una variable que sea una instancia de la enumeración Velocidades, llamada: velocidad.

Las funciones o métodos que define la clase Auto son las siguientes:

- init( ), agrega la función inicializadora que crea una instancia de Velocidades: velocidad, debe iniciar en Apagado. Recuerda que la enumeración tiene su función inicializadora.

- func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String), la función cambioDeVelocidad, cambia el valor de velocidad a la siguiente velocidad gradual, por ejemplo: Apagado cambia a VelocidadBaja, de VelocidadBaja cambia a VelocidadMedia, es decir cada ejecución cambia a la siguiente velocidad.. si llega a VelocidadAlta cambia a VelocidadMedia. Finalmente, la función debe regresar una tupla con la velocidad actual y una cadena con la leyenda de la velocidad correspondiente.
 
 - En el mismo playground prueba crea una instancia de la clase Auto, llamada auto.
 
 - Itera 20 veces usando un for, llama a la función cambioDeVelocidad e imprime los valores de la tupla en la consola.
 
 - Una salida válida con cinco iteraciones es:
 


*/

import UIKit

var numeros = 1...100
for num in numeros {
    if num % 2 == 0 {
        print ("#\(num) par!!!")
        if num < 41 && num > 29{
            print ("#\(num) Viva Swift!!!")
        }
        if num % 5 == 0 {
            print ("#\(num) Bingo!!!")
        }
    }
    else {
        print ("#\(num) impar!!!")
        if num < 41 && num > 29{
            print ("#\(num) Viva Swift!!!")
        }
        if num % 5 == 0 {
            print ("#\(num) Bingo!!!")
        }
    }
}

